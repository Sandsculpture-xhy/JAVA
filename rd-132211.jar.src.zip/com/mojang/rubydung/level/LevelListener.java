package com.mojang.rubydung.level;

public interface LevelListener {
  void tileChanged(int paramInt1, int paramInt2, int paramInt3);
  
  void lightColumnChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void allChanged();
}


/* Location:              C:\Users\HaoyuanX36054\JAVA\.minecraft\versions\rd-132211\rd-132211.jar!\com\mojang\rubydung\level\LevelListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */