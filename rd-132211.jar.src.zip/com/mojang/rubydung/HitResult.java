/*    */ package com.mojang.rubydung;
/*    */ 
/*    */ public class HitResult
/*    */ {
/*    */   public int x;
/*    */   public int y;
/*    */   
/*    */   public HitResult(int x, int y, int z, int o, int f) {
/*  9 */     this.x = x;
/* 10 */     this.y = y;
/* 11 */     this.z = z;
/* 12 */     this.o = o;
/* 13 */     this.f = f;
/*    */   }
/*    */   
/*    */   public int z;
/*    */   public int o;
/*    */   public int f;
/*    */ }


/* Location:              C:\Users\HaoyuanX36054\JAVA\.minecraft\versions\rd-132211\rd-132211.jar!\com\mojang\rubydung\HitResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */